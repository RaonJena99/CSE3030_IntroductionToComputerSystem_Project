#ifndef COPYLSB_H
#define COPYLSB_H
int copyLSB(int x);
#endif
