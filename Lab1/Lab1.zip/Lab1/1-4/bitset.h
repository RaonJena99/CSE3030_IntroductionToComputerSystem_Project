#ifndef BITSET_H
#define BITSET_H
void addNumber(unsigned char* set, int x);
#endif
