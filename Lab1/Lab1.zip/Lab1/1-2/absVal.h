#ifndef ABSVAL_H
#define ABSVAL_H
int absVal(int x);
#endif
