#ifndef CONDITIONAL_H
#define CONDITIONAL_H
int conditional(int x, int y, int z);
#endif
